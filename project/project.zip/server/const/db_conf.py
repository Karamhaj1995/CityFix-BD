db_config = {
    "connection" : "localhost",
    "port" : "27017",
    "dbname" : "CityFix",
    "dbusername" : "",
    "dbpassword" : ""
}